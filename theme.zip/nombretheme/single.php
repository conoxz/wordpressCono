<?php get_header(); ?>
<?php $theme = get_template_directory_uri(); ?>

<?php 
		while ( have_posts() ) {
			the_post(); 
										
?>
			
<!-- Contenido -->
<?php 	
											
			} // Fin de While
?>
			
			
			
<?php get_footer(); ?>