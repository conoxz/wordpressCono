<?php 
 	
	add_image_size( 'logo', 200, auto, true );

	
//  MENU PARA OPTIONS WP
	if( function_exists('acf_set_options_page_title') )
	{
	    acf_set_options_page_title( __('Nombre de P���gina') );
	}	
	
	function my_acf_options_page_settings( $settings )
	{
        /*$settings['title'] = '';*/
		$settings['pages'] = array('Inicio','Nosotros','Recetas');
		
		return $settings;
	}
	
	add_filter('acf/options_page/settings', 'my_acf_options_page_settings'); 
	
// Reducir tama���o de letras historia
	function tamano_generico($tamano,$texto) {
		global $post;
		$text = $texto;
		if ( '' != $text ) {
			$text = strip_shortcodes( $text );
			$excerpt_length = $tamano; // 15 words
			$excerpt_more = apply_filters('excerpt_more', ' ' . '...');
			$text = wp_trim_words( $text, $excerpt_length, $excerpt_more );
		}
		return apply_filters('the_excerpt', $text);
	}
	
	
	
 	 	
add_filter( 'show_admin_bar', '__return_false' );