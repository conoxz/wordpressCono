<!DOCTYPE html>
<?php $theme = get_template_directory_uri(); ?>
<html lang="en">
<head>
    <!-- Documento Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="copyright" content="" />
    <meta name="robots" content="all" />
    <meta name="description" content="" />
    
        
 <title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :: '; } ?><?php bloginfo('name'); if(is_home()) { echo ' :: '; bloginfo('description'); } ?></title>
    <link href="<?php echo $theme ?>/images/icon.png" rel="icon">


    <!-- CSS  -->
    
    <!-- CSS Resetea Todo los estilos 
    <link href="<?php echo $theme ?>/css/reset.css" rel="stylesheet">  -->
    <!-- CSS Efectos y animaciones
    <link rel="stylesheet" type="text/css" href="<?php echo $theme ?>/css/animate.css">-->


    
<?php wp_head(); ?>
</head>

<body>