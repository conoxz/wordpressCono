<?php // Do not delete these lines
	if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');
	
	if ( post_password_required() ) { ?>
		<p class="nocomments"><?php _e('This post is password protected. Enter the password to view comments.'); ?></p> 
	<?php
		return;
	}
?>

<!-- You can start editing here. -->


<?php if ( have_comments() ) : ?>

<div id="comments" class="limpiar">

	<h2><span class="red"><?php comments_popup_link(__('0',THEMENAME ), __('1',THEMENAME ), __('%',THEMENAME )); ?></span> Comentarios</h2>

	<ol class="commentlist limpiar">
	
		<?php wp_list_comments('type=comment&callback=format_comment');?>
	
	</ol>

</div>

 <?php else : // this is displayed if there are no comments so far ?>

	<?php if ('open' == $post->comment_status) : ?>
		<!-- If comments are open, but there are no comments. -->
	

	<?php else : // comments are closed ?>
		<!-- If comments are closed. -->
		<p class="nocomments"><?php _e('Los comentarios se han cerrado.'); ?></p>

	<?php endif; ?>
<?php endif; ?>


<?php if ('open' == $post->comment_status) : ?>



<div id="respond" class="limpiar">

<h2><span class="red">&raquo;</span> <?php comment_form_title( __('Dejanos tu comentario'), __('Dejanos tu comentario %s') ); ?></h2>

<div id="cancel-comment-reply"> 
	<small><?php cancel_comment_reply_link() ?></small>
</div> 

<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p><?php printf(__('Debes de estar <a href="%s">loggeado</a> para poder comentar.'), get_option('siteurl') . '/wp-login.php?redirect_to=' . urlencode(get_permalink())); ?></p>
<?php else : ?>

<div id="forma">

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">

<?php if ( $user_ID ) : ?>
<br />

<p><?php printf(__('Conectado como <a href="%1$s">%2$s</a>.'), get_option('siteurl') . '/wp-admin/profile.php', $user_identity); ?> <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="<?php _e('Salir de tu cuenta'); ?>"><?php _e('Log out &raquo;'); ?></a></p>

<br />

<?php else : ?>

<!-- COMIENZA AUTOR -->



<div class="inputform limpiar">
    
    <div class="left inputwrap"><input type="text" onclick="this.value='';" name="author" id="author"  class="input" value="Tu nombre*" size="22" tabindex="1" <?php if ($req) echo "aria-required='true'"; ?> /></div>

</div>

<!-- TERMINA AUTOR -->

<!-- COMIENZA MAIL -->

<div class="inputform limpiar">

	
    
    <div class="left inputwrap"><input onclick="this.value='';" type="text" name="email" id="email" class="input" value="Tu email*" size="22" tabindex="2" <?php if ($req) echo "aria-required='true'"; ?> /></div>

</div>

<!-- TERMINA MAIL -->

<!-- COMIENZA WEB -->

<div class="inputform limpiar">
    
    <div class="left inputwrap"><input onclick="this.value='';" type="text" name="url" id="url" class="input" value="Tu website" size="22" tabindex="3" /></div>

</div>

<!-- TERMINA WEB -->

<?php endif; ?>

<!--<p><small><?php printf(__('<strong>XHTML:</strong> You can use these tags: <code>%s</code>'), allowed_tags()); ?></small></p>-->

<div >

    <p><textarea name="comment" id="comment" cols="100%" rows="10" tabindex="4" class="areacomentario" onclick="this.value='';">Tu comentario*</textarea></p>

</div>

<p id="obli">* Estos campos son obligatorios</p>

<p><input name="submit" type="submit" id="submit" tabindex="5" value="<?php _e('Enviar mi comentario'); ?>" />
<?php comment_id_fields(); ?> 
</p>
<?php do_action('comment_form', $post->ID); ?>

</form>

</div>

<?php endif; // If registration required and not logged in ?>
</div>

<?php endif; // if you delete this the sky will fall on your head ?>