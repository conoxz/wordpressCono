<?php $theme = get_template_directory_uri(); ?>







<?php wp_footer(); ?>
</body>

</html>
