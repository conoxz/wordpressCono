<?php get_header(); ?>
<?php $theme = get_template_directory_uri(); ?>
      
<!-- Imprimir un repeater  -->                    
<?php if( have_rows('nombre_repeater','options') ): while ( have_rows('nombre_repeater','options') ) : the_row(); ?>	
      <?php  the_sub_field('titulo');?>
      <?php  echo   get_sub_field('contenido');?>

    
<?php endwhile; endif; ?>     

<!-- Cuando quieres imprimir un grupo -->
<?php $Grupo=get_field('nombre_grupo','options');
	  $titulo=$Grupo['titulo'];
	  $sub_titulo=$Grupo['sub_titulo'];
	  $contenido=$Grupo['contenido'];
?>


  <!-- Blog-->
<?php 
		$args=array('post_type'=>'post','orderby'=>'ID','posts_per_page'=> '3');
		$the_query=new WP_Query($args);
		if ( $the_query->have_posts() ) {
			 while ( $the_query->have_posts() ) {
			 $the_query->the_post(); 
?>
    <!-- Contenido del Blog -->
    <?php echo get_the_date('M-d-Y');?>
    <?php the_title(); ?>
    <?php the_permalink(); ?>
    <?php echo get_field('imagen')['sizes']['nombre_del_image_size']; ?>
    <!-- o -->
    <?php echo get_field('imagen')['url'] ?>
     <?php echo tamano_generico(25,get_the_content()); ?>
    
<?php 	
			} // Fin while
		} // Fin if
?>            

        
        
<?php get_footer(); ?>